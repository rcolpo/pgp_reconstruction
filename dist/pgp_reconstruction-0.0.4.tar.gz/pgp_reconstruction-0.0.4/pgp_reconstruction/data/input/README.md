Upon the initial execution of PGP_Reconstruction, this directory will host a local copy of the essential genes, sourced from the DEG Database (a database from a collection of essential genes experiments).

In case the automatic download operation is unsuccessful, these files can be manually retrieved. To do this, navigate to the following URL: http://origin.tubic.org/deg/public/index.php/download.

When presented with various download options, please choose the "Annotations" option. This will provide the necessary files for PGP_Reconstruction to function correctly.